# -*- coding: utf-8 -*-
"""1일 여행 - 시간 여유롭게 (실제 API)"""
import requests
import json

BASE_URL = "http://localhost:8000"

test_data = {
    "date": {
        "user_id": "test_1day_relaxed",
        "start_date": "2025-02-01",
        "end_date": "2025-02-01",
        "arrival_time": "08:00",  # 더 일찍
        "departure_time": "20:00",  # 더 늦게 (총 12시간)
        "start_place": "제주공항",
        "end_place": "제주공항"
    },
    "user": {
        "start_time": "08:00",
        "end_time": "20:00",
        "travel_style": "relaxed",  # 여유로운 스타일
        "meal_time_preferences": {
            "lunch": ["12:00", "14:00"],  # 더 넓은 시간대
            "dinner": ["18:00", "20:00"]
        },
        "tags": ["자연", "바다"]  # 태그 줄임
    },
    "start_transport_id": 1,
    "end_transport_id": 1,
    "total_days": 1,
    "daily_locations": [10],
    "hashtags": ["자연", "바다"],
    "use_mock": False
}

print("1-Day Trip - Relaxed Schedule (Real API)")
print("="*80)

try:
    response = requests.post(
        f"{BASE_URL}/api/users/schedules/init",
        json=test_data,
        timeout=120
    )

    if response.status_code == 200:
        result = response.json()
        day = result['day_schedules'][0]

        print(f"Visits: {len(day['visits'])}")
        print(f"Path segments: {len(day['path'])}")
        print(f"Retry attempts: {len(day['retry_history'])}")

        if day['retry_history']:
            last = day['retry_history'][-1]
            print(f"Final: attempt {last['attempt']} - {'SUCCESS' if last['success'] else 'FAILED'}")

        if day['path']:
            print(f"\nSUCCESS! Path generated with {len(day['path'])} segments")
        else:
            print(f"\nFAILED: No path")

        with open('test_1day_relaxed_result.json', 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

except Exception as e:
    print(f"Error: {e}")
