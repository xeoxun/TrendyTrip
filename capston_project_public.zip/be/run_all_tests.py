"""
통합 테스트 스크립트 - 모든 테스트 케이스 실행
총 50개 테스트 (기본 14 + 엣지 15 + 고급 21)
"""

import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests
import json
import time
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8009/api/users/schedules/init"

# 유효한 지역 코드
AVAILABLE_LOCATIONS = [10, 20, 101, 102, 103, 104, 105, 201, 202, 203, 204, 205, 206]

# 전역 결과 저장
all_results = []

def create_test_request(days, daily_locations, hashtags=None, start_time="09:00", end_time="18:00", travel_style="relaxed"):
    """테스트 요청 데이터 생성 - API 스키마에 맞게"""
    if hashtags is None:
        hashtags = ["맛집", "카페"]

    start_date = datetime.now() + timedelta(days=7)
    end_date = start_date + timedelta(days=days-1)

    return {
        "date": {
            "user_id": "test_user",
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "arrival_time": start_time,
            "departure_time": end_time,
            "start_place": "제주국제공항",
            "end_place": "제주국제공항"
        },
        "user": {
            "start_time": start_time,
            "end_time": end_time,
            "travel_style": travel_style,
            "meal_time_preferences": {
                "breakfast": ["08:00", "09:00"],
                "lunch": ["12:00", "13:00"],
                "dinner": ["18:00", "19:00"]
            },
            "tags": hashtags
        },
        "daily_locations": daily_locations,
        "use_mock": False
    }

def run_test(test_name, days, daily_locations, hashtags=None, start_time="09:00", end_time="18:00", travel_style="relaxed", category="기타"):
    """단일 테스트 실행"""
    request_data = create_test_request(days, daily_locations, hashtags, start_time, end_time, travel_style)

    print(f"\n[{test_name}] 실행 중...", end=" ", flush=True)

    start = time.time()
    try:
        response = requests.post(BASE_URL, json=request_data, timeout=300)
        elapsed = time.time() - start

        if response.status_code == 200:
            data = response.json()
            if data.get("success") and data.get("day_schedules"):
                total_places = sum(len(day.get("visits", [])) for day in data["day_schedules"])
                print(f"SUCCESS ({elapsed:.1f}s, {total_places}개 장소)")
                all_results.append({
                    "name": test_name,
                    "category": category,
                    "success": True,
                    "time": elapsed,
                    "places": total_places
                })
                return True
            else:
                error_msg = data.get("error", "일정 없음")
                print(f"FAIL - {error_msg[:30]} ({elapsed:.1f}s)")
                all_results.append({"name": test_name, "category": category, "success": False, "time": elapsed, "error": error_msg[:50]})
                return False
        else:
            print(f"FAIL - HTTP {response.status_code} ({elapsed:.1f}s)")
            all_results.append({"name": test_name, "category": category, "success": False, "time": elapsed, "error": f"http_{response.status_code}"})
            return False
    except requests.exceptions.Timeout:
        elapsed = time.time() - start
        print(f"FAIL - Timeout ({elapsed:.1f}s)")
        all_results.append({"name": test_name, "category": category, "success": False, "time": elapsed, "error": "timeout"})
        return False
    except Exception as e:
        elapsed = time.time() - start
        print(f"FAIL - {str(e)[:50]} ({elapsed:.1f}s)")
        all_results.append({"name": test_name, "category": category, "success": False, "time": elapsed, "error": str(e)[:50]})
        return False

def run_basic_tests():
    """기본 테스트 14개"""
    print("\n" + "="*70)
    print("기본 테스트 (14개)")
    print("="*70)

    # 1일 테스트 (4개)
    run_test("1일-제주시", 1, [10], category="1일")
    run_test("1일-서귀포", 1, [20], category="1일")
    run_test("1일-애월", 1, [101], category="1일")
    run_test("1일-성산", 1, [201], category="1일")

    # 2일 테스트 (5개)
    run_test("2일-제주시+서귀포", 2, [10, 20], category="2일")
    run_test("2일-애월+중문", 2, [101, 102], category="2일")
    run_test("2일-한림+한경", 2, [103, 104], category="2일")
    run_test("2일-성산+표선", 2, [201, 202], category="2일")
    run_test("2일-남원+안덕", 2, [203, 204], category="2일")

    # 3일 테스트 (5개)
    run_test("3일-제주+서귀포+애월", 3, [10, 20, 101], category="3일")
    run_test("3일-중문+한림+한경", 3, [102, 103, 104], category="3일")
    run_test("3일-구좌+성산+표선", 3, [105, 201, 202], category="3일")
    run_test("3일-남원+안덕+대정", 3, [203, 204, 205], category="3일")
    run_test("3일-조천+제주+서귀포", 3, [206, 10, 20], category="3일")

def run_edge_tests():
    """엣지 케이스 테스트 15개"""
    print("\n" + "="*70)
    print("엣지 케이스 테스트 (15개)")
    print("="*70)

    # 4일 테스트 (3개)
    run_test("4일-동부권", 4, [105, 201, 202, 206], category="4-5일")
    run_test("4일-서부권", 4, [101, 103, 104, 205], category="4-5일")
    run_test("4일-남부권", 4, [20, 102, 203, 204], category="4-5일")

    # 5일 테스트 (3개)
    run_test("5일-제주일주A", 5, [10, 101, 103, 20, 201], category="4-5일")
    run_test("5일-제주일주B", 5, [10, 206, 105, 201, 20], category="4-5일")
    run_test("5일-혼합코스", 5, [10, 102, 201, 103, 20], category="4-5일")

    # 작은 지역 테스트 (3개)
    run_test("2일-한경+대정", 2, [104, 205], category="작은지역")
    run_test("2일-조천+구좌", 2, [206, 105], category="작은지역")
    run_test("2일-표선+남원", 2, [202, 203], category="작은지역")

    # 시간 변형 테스트 (6개)
    run_test("2일-오전만(~14시)", 2, [10, 20], start_time="09:00", end_time="14:00", category="시간변형")
    run_test("2일-오후만(14시~)", 2, [10, 20], start_time="14:00", end_time="21:00", category="시간변형")
    run_test("2일-짧은시간(4h)", 2, [10, 20], start_time="10:00", end_time="14:00", category="시간변형")
    run_test("2일-긴시간(12h)", 2, [10, 20], start_time="08:00", end_time="20:00", category="시간변형")
    run_test("1일-최단(3h)", 1, [10], start_time="10:00", end_time="13:00", category="시간변형")
    run_test("1일-최장(15h)", 1, [10], start_time="07:00", end_time="22:00", category="시간변형")

def run_advanced_tests():
    """고급 테스트 21개"""
    print("\n" + "="*70)
    print("고급 테스트 (21개)")
    print("="*70)

    # 장기 여행 (3개)
    run_test("6일-완전일주", 6, [10, 101, 103, 20, 201, 202], category="장기여행")
    run_test("7일-제주일주", 7, [10, 101, 102, 103, 20, 201, 202], category="장기여행")
    run_test("13일-전지역", 13, [10, 101, 103, 104, 105, 20, 102, 201, 202, 203, 204, 205, 206], category="장기여행")

    # 해시태그 테스트 (6개)
    run_test("2일-액티비티", 2, [10, 20], hashtags=["액티비티", "체험", "레저"], category="해시태그")
    run_test("2일-힐링", 2, [101, 102], hashtags=["힐링", "휴식", "자연"], category="해시태그")
    run_test("2일-문화역사", 2, [10, 201], hashtags=["문화", "역사", "박물관"], category="해시태그")
    run_test("2일-가족여행", 2, [10, 20], hashtags=["가족", "아이", "체험"], category="해시태그")
    run_test("2일-커플여행", 2, [101, 102], hashtags=["데이트", "로맨틱", "뷰맛집"], category="해시태그")
    run_test("2일-사진명소", 2, [201, 202], hashtags=["인스타", "사진", "포토스팟"], category="해시태그")

    # 여행 스타일 테스트 (3개)
    run_test("2일-relaxed", 2, [10, 20], travel_style="relaxed", category="스타일")
    run_test("2일-normal", 2, [10, 20], travel_style="normal", category="스타일")
    run_test("2일-tight", 2, [10, 20], travel_style="tight", category="스타일")

    # 극단적 시간 (3개)
    run_test("1일-이른아침(6-12)", 1, [10], start_time="06:00", end_time="12:00", category="극단시간")
    run_test("1일-늦은저녁(17-23)", 1, [20], start_time="17:00", end_time="23:00", category="극단시간")
    run_test("1일-풀타임(6-23)", 1, [10], start_time="06:00", end_time="23:00", category="극단시간")

    # 지역 조합 (4개)
    run_test("3일-원거리이동", 3, [10, 20, 201], category="지역조합")
    run_test("3일-인접지역", 3, [101, 103, 104], category="지역조합")
    run_test("4일-교차이동", 4, [10, 201, 20, 101], category="지역조합")
    run_test("3일-서귀포권", 3, [20, 102, 203], category="지역조합")

    # 반복 패턴 (2개)
    run_test("4일-2지역왕복", 4, [10, 20, 10, 20], category="반복패턴")
    run_test("6일-3지역순환", 6, [10, 20, 101, 10, 20, 101], category="반복패턴")

def print_summary():
    """결과 요약 출력"""
    print("\n" + "="*70)
    print("전체 테스트 결과 요약")
    print("="*70)

    total = len(all_results)
    success = sum(1 for r in all_results if r["success"])
    failed = total - success

    print(f"\n총 테스트: {total}개")
    print(f"성공: {success}개")
    print(f"실패: {failed}개")
    print(f"성공률: {success/total*100:.1f}%")

    # 소요시간 통계
    times = [r["time"] for r in all_results]
    print(f"\n소요시간: 최소 {min(times):.1f}s / 최대 {max(times):.1f}s / 평균 {sum(times)/len(times):.1f}s")
    print(f"총 소요시간: {sum(times):.1f}s ({sum(times)/60:.1f}분)")

    # 장소 수 통계
    places = [r["places"] for r in all_results if r["success"]]
    if places:
        print(f"\n방문장소: 최소 {min(places)}개 / 최대 {max(places)}개 / 평균 {sum(places)/len(places):.1f}개")

    # 카테고리별 결과
    categories = {}
    for r in all_results:
        cat = r["category"]
        if cat not in categories:
            categories[cat] = {"total": 0, "success": 0}
        categories[cat]["total"] += 1
        if r["success"]:
            categories[cat]["success"] += 1

    print("\n카테고리별 결과:")
    for cat, data in categories.items():
        status = "OK" if data["success"] == data["total"] else "FAIL"
        print(f"  {cat}: {data['success']}/{data['total']} [{status}]")

    # 실패 목록
    if failed > 0:
        print("\n실패한 테스트:")
        for r in all_results:
            if not r["success"]:
                print(f"  - {r['name']}: {r.get('error', 'unknown')}")

    return success == total

def main():
    print("="*70)
    print("통합 테스트 시작 - 총 50개 테스트")
    print(f"시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

    total_start = time.time()

    # 모든 테스트 실행
    run_basic_tests()
    run_edge_tests()
    run_advanced_tests()

    total_elapsed = time.time() - total_start

    # 결과 요약
    all_passed = print_summary()

    print(f"\n총 실행 시간: {total_elapsed:.1f}초 ({total_elapsed/60:.1f}분)")
    print(f"종료 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    if all_passed:
        print("\n모든 테스트 통과!")
    else:
        print("\n일부 테스트 실패!")

    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())
