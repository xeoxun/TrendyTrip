"""
여행 일정 생성 API 테스트 스크립트
다양한 시나리오로 오류 추적 기능을 테스트합니다.
"""

import requests
import json
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8000"

# 테스트 시나리오 정의
TEST_SCENARIOS = [
    {
        "name": "1일 여행 - 제주시 (지역코드 10)",
        "data": {
            "date": {
                "user_id": "test_user_001",
                "start_date": "2025-02-01",
                "end_date": "2025-02-01",
                "arrival_time": "09:00",
                "departure_time": "18:00",
                "start_place": "제주공항",
                "end_place": "제주공항"
            },
            "user": {
                "start_time": "09:00",
                "end_time": "18:00",
                "travel_style": "relaxed",
                "meal_time_preferences": {
                    "lunch": ["12:00", "13:00"],
                    "dinner": ["18:00", "19:00"]
                },
                "tags": ["자연", "힐링", "바다"]
            },
            "start_transport_id": 1,
            "end_transport_id": 1,
            "total_days": 1,
            "daily_locations": [10],  # 제주시
            "hashtags": ["자연", "힐링", "바다"],
            "use_mock": True
        }
    },
    {
        "name": "2일 여행 - 제주시 → 서귀포 (지역코드 10 → 11)",
        "data": {
            "date": {
                "user_id": "test_user_002",
                "start_date": "2025-02-15",
                "end_date": "2025-02-16",
                "arrival_time": "10:00",
                "departure_time": "17:00",
                "start_place": "제주공항",
                "end_place": "제주공항"
            },
            "user": {
                "start_time": "09:00",
                "end_time": "19:00",
                "travel_style": "normal",
                "meal_time_preferences": {
                    "lunch": ["12:00", "14:00"],
                    "dinner": ["18:00", "20:00"]
                },
                "tags": ["맛집", "카페", "풍경"]
            },
            "start_transport_id": 1,
            "end_transport_id": 1,
            "total_days": 2,
            "daily_locations": [10, 11],  # 제주시, 서귀포
            "hashtags": ["맛집", "카페", "풍경"],
            "use_mock": True
        }
    },
    {
        "name": "3일 여행 - 제주시 → 동부 → 서귀포 (지역코드 10 → 101 → 11)",
        "data": {
            "date": {
                "user_id": "test_user_003",
                "start_date": "2025-03-01",
                "end_date": "2025-03-03",
                "arrival_time": "08:00",
                "departure_time": "20:00",
                "start_place": "제주공항",
                "end_place": "제주공항"
            },
            "user": {
                "start_time": "08:00",
                "end_time": "20:00",
                "travel_style": "packed",
                "meal_time_preferences": {
                    "breakfast": ["08:00", "09:00"],
                    "lunch": ["12:00", "13:00"],
                    "dinner": ["18:00", "19:00"]
                },
                "tags": ["자연", "관광", "사진"]
            },
            "start_transport_id": 1,
            "end_transport_id": 1,
            "total_days": 3,
            "daily_locations": [10, 101, 11],  # 제주시, 동부, 서귀포
            "hashtags": ["자연", "관광", "사진"],
            "use_mock": True
        }
    },
    {
        "name": "1일 여행 - 동부 지역 (지역코드 101)",
        "data": {
            "date": {
                "user_id": "test_user_004",
                "start_date": "2025-02-20",
                "end_date": "2025-02-20",
                "arrival_time": "09:00",
                "departure_time": "18:00",
                "start_place": "제주공항",
                "end_place": "제주공항"
            },
            "user": {
                "start_time": "09:00",
                "end_time": "18:00",
                "travel_style": "relaxed",
                "meal_time_preferences": {
                    "lunch": ["12:00", "13:00"],
                    "dinner": ["18:00", "19:00"]
                },
                "tags": ["해변", "드라이브", "일출"]
            },
            "start_transport_id": 1,
            "end_transport_id": 1,
            "total_days": 1,
            "daily_locations": [101],  # 동부
            "hashtags": ["해변", "드라이브", "일출"],
            "use_mock": True
        }
    }
]


def print_separator(char="=", length=100):
    """구분선 출력"""
    print(char * length)


def print_test_header(scenario_name, scenario_num, total_scenarios):
    """테스트 헤더 출력"""
    print_separator("=")
    print(f"테스트 {scenario_num}/{total_scenarios}: {scenario_name}")
    print_separator("=")


def print_error_tracking_info(day_schedule, day_num):
    """오류 추적 정보 출력"""
    print(f"\n[ Day {day_num} 오류 추적 정보 ]")
    print("-" * 80)

    # 1. 장소 선택 오류
    selection_errors = day_schedule.get('selection_errors', [])
    if selection_errors:
        print(f"\n⚠️  장소 선택 오류: {len(selection_errors)}건")
        for i, err in enumerate(selection_errors, 1):
            print(f"  {i}. [{err.get('type')}] {err.get('message')}")
            print(f"     - 장소 타입: {err.get('place_type')}")
            print(f"     - 지역 코드: {err.get('location_code')}")
            print(f"     - 요청 개수: {err.get('requested_count')}")
    else:
        print("\n✅ 장소 선택 오류: 없음")

    # 2. 장소 선택 요약
    summary = day_schedule.get('selection_summary', {})
    if summary:
        print(f"\n📊 장소 선택 요약:")
        print(f"  - 총 선택: {summary.get('total_selected', 0)}개")
        print(f"  - 총 요청: {summary.get('total_requested', 0)}개")
        print(f"  - 성공률: {summary.get('success_rate', 0)*100:.1f}%")

        types_completed = summary.get('types_completed', [])
        types_partial = summary.get('types_partial', [])
        types_failed = summary.get('types_failed', [])

        if types_completed:
            print(f"  - 완료된 타입: {', '.join(types_completed)}")
        if types_partial:
            print(f"  - 부분 완료: {', '.join(types_partial)}")
        if types_failed:
            print(f"  - 실패한 타입: {', '.join(types_failed)}")

    # 3. 재시도 이력
    retry_history = day_schedule.get('retry_history', [])
    if retry_history:
        print(f"\n🔄 재시도 이력: {len(retry_history)}번")
        for r in retry_history:
            attempt = r.get('attempt', '?')
            success = "✅ 성공" if r.get('success') else "❌ 실패"
            strategy = r.get('strategy', '')

            if strategy:
                print(f"  - 시도 {attempt}: {success} [전략: {strategy}]")
            else:
                time_limit = r.get('time_limit', '?')
                window_slack = r.get('window_slack', '?')
                print(f"  - 시도 {attempt}: {success} [제한: {time_limit}s, 여유: {window_slack}분]")

            if not r.get('success') and r.get('error'):
                print(f"      오류: {r.get('error')[:100]}")
    else:
        print("\n✅ 재시도 이력: 1차 시도 성공")


def print_visits_summary(visits):
    """방문 장소 요약 출력"""
    print("\n📍 방문 장소:")
    for i, visit in enumerate(visits, 1):
        place = visit.get('place', 'N/A')
        category = visit.get('category', 'N/A')
        arrival = visit.get('arrival', 'N/A')
        departure = visit.get('departure', 'N/A')

        print(f"  {i}. {place} ({category})")
        print(f"     도착: {arrival} → 출발: {departure}")


def run_test_scenario(scenario, scenario_num, total_scenarios):
    """단일 시나리오 테스트 실행"""
    print_test_header(scenario['name'], scenario_num, total_scenarios)

    # 요청 데이터 출력
    test_data = scenario['data']
    print(f"\n📝 요청 정보:")
    print(f"  - 여행 기간: {test_data['date']['start_date']} ~ {test_data['date']['end_date']}")
    print(f"  - 총 일수: {test_data['total_days']}일")
    print(f"  - 지역 코드: {test_data['daily_locations']}")
    print(f"  - 해시태그: {test_data['hashtags']}")
    print(f"  - 여행 스타일: {test_data['user']['travel_style']}")
    print(f"  - Mock 사용: {test_data['use_mock']}")

    try:
        # API 호출
        print(f"\n🚀 API 호출 중...")
        response = requests.post(
            f"{BASE_URL}/api/users/schedules/init",
            json=test_data,
            timeout=120
        )

        print(f"✅ 응답 상태 코드: {response.status_code}")

        if response.status_code == 200:
            result = response.json()

            # 전체 결과 요약
            print(f"\n📊 전체 결과:")
            print(f"  - 성공 여부: {result.get('success')}")
            print(f"  - 총 일수: {result.get('total_days')}")

            # 각 날짜별 상세 정보
            day_schedules = result.get('day_schedules', [])
            print(f"  - 생성된 일정: {len(day_schedules)}일")

            for day_schedule in day_schedules:
                day_num = day_schedule.get('day', 0)
                date = day_schedule.get('date', '')
                visits = day_schedule.get('visits', [])
                path = day_schedule.get('path', [])

                print_separator("-")
                print(f"\n📅 Day {day_num} ({date})")
                print(f"방문 장소 수: {len(visits)}개")
                print(f"경로 세그먼트: {len(path)}개")

                # 방문 장소 출력
                if visits:
                    print_visits_summary(visits)

                # 오류 추적 정보 출력
                print_error_tracking_info(day_schedule, day_num)

            # 테스트 성공
            print_separator("-")
            print(f"\n✅ 테스트 완료: {scenario['name']}")
            return True

        else:
            print(f"\n❌ API 오류:")
            print(f"  - 상태 코드: {response.status_code}")
            print(f"  - 응답: {response.text[:500]}")
            return False

    except Exception as e:
        print(f"\n❌ 테스트 실패: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_server_status():
    """서버 상태 확인"""
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        if response.status_code == 200:
            print(f"✅ 서버 연결 성공: {BASE_URL}")
            return True
        else:
            print(f"❌ 서버 응답 오류: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 서버 연결 실패: {e}")
        print(f"   서버를 먼저 실행해주세요: uvicorn app.main:app --reload")
        return False


def main():
    """메인 테스트 실행"""
    print_separator("=")
    print("🧪 여행 일정 생성 API 테스트")
    print(f"   시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print_separator("=")

    # 서버 상태 확인
    print("\n1️⃣  서버 상태 확인...")
    if not check_server_status():
        return

    print("\n2️⃣  테스트 시나리오 실행...")
    print(f"   총 {len(TEST_SCENARIOS)}개의 시나리오를 테스트합니다.\n")

    # 각 시나리오 실행
    results = []
    for i, scenario in enumerate(TEST_SCENARIOS, 1):
        success = run_test_scenario(scenario, i, len(TEST_SCENARIOS))
        results.append({
            'name': scenario['name'],
            'success': success
        })
        print("\n")

    # 최종 결과 요약
    print_separator("=")
    print("📊 최종 테스트 결과")
    print_separator("=")

    success_count = sum(1 for r in results if r['success'])
    total_count = len(results)

    print(f"\n총 {total_count}개 시나리오 중 {success_count}개 성공")
    print(f"성공률: {success_count/total_count*100:.1f}%\n")

    for i, result in enumerate(results, 1):
        status = "✅ 성공" if result['success'] else "❌ 실패"
        print(f"{i}. {status} - {result['name']}")

    print_separator("=")

    if success_count == total_count:
        print("\n🎉 모든 테스트가 성공했습니다!")
    else:
        print(f"\n⚠️  {total_count - success_count}개의 테스트가 실패했습니다.")

    print_separator("=")


if __name__ == "__main__":
    main()
