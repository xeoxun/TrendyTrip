"""
포괄적인 여행 일정 생성 API 테스트
- 모든 지역 코드 조합
- 1일/2일/3일/4일 여행
- 다양한 해시태그 조합
- 결과를 JSON으로 저장
"""

import requests
import json
from datetime import datetime, timedelta
from pathlib import Path

BASE_URL = "http://localhost:8000"
RESULTS_DIR = Path("test_results")
RESULTS_DIR.mkdir(exist_ok=True)

# 제주 지역 코드 정의
LOCATION_CODES = {
    10: "제주시",
    11: "서귀포시",
    101: "동부(구좌/성산)",
    102: "서부(한림/애월)",
    103: "남부(안덕/대정/남원)",
    104: "중산간"
}

# 해시태그 조합
HASHTAG_SETS = {
    "자연힐링": ["자연", "힐링", "바다"],
    "맛집투어": ["맛집", "카페", "디저트"],
    "액티비티": ["서핑", "다이빙", "체험"],
    "가족여행": ["가족", "아이", "체험"],
    "감성여행": ["카페", "감성", "사진"],
    "전통문화": ["문화", "전통", "역사"]
}

# 여행 스타일
TRAVEL_STYLES = ["relaxed", "normal", "packed"]


def generate_test_scenarios():
    """다양한 테스트 시나리오 생성"""
    scenarios = []
    test_id = 1

    # 1일 여행 - 모든 지역 코드
    for loc_code, loc_name in LOCATION_CODES.items():
        for hashtag_name, hashtags in HASHTAG_SETS.items():
            scenarios.append({
                "test_id": f"1D_{test_id:03d}",
                "name": f"1일 여행 - {loc_name} ({hashtag_name})",
                "total_days": 1,
                "daily_locations": [loc_code],
                "hashtags": hashtags,
                "travel_style": "relaxed",
                "start_date": "2025-03-01"
            })
            test_id += 1

    # 2일 여행 - 지역 조합
    two_day_combinations = [
        ([10, 11], "제주시 → 서귀포"),
        ([10, 101], "제주시 → 동부"),
        ([10, 102], "제주시 → 서부"),
        ([11, 103], "서귀포 → 남부"),
        ([101, 102], "동부 → 서부"),
        ([102, 103], "서부 → 남부")
    ]

    for locations, loc_desc in two_day_combinations:
        for hashtag_name, hashtags in list(HASHTAG_SETS.items())[:3]:  # 3개만
            scenarios.append({
                "test_id": f"2D_{test_id:03d}",
                "name": f"2일 여행 - {loc_desc} ({hashtag_name})",
                "total_days": 2,
                "daily_locations": locations,
                "hashtags": hashtags,
                "travel_style": "normal",
                "start_date": "2025-03-10"
            })
            test_id += 1

    # 3일 여행 - 지역 조합
    three_day_combinations = [
        ([10, 101, 11], "제주시 → 동부 → 서귀포"),
        ([10, 102, 103], "제주시 → 서부 → 남부"),
        ([10, 104, 11], "제주시 → 중산간 → 서귀포"),
        ([102, 101, 11], "서부 → 동부 → 서귀포"),
        ([10, 11, 103], "제주시 → 서귀포 → 남부")
    ]

    for locations, loc_desc in three_day_combinations:
        for hashtag_name, hashtags in list(HASHTAG_SETS.items())[:2]:  # 2개만
            scenarios.append({
                "test_id": f"3D_{test_id:03d}",
                "name": f"3일 여행 - {loc_desc} ({hashtag_name})",
                "total_days": 3,
                "daily_locations": locations,
                "hashtags": hashtags,
                "travel_style": "packed",
                "start_date": "2025-03-20"
            })
            test_id += 1

    # 4일 여행 - 지역 조합
    four_day_combinations = [
        ([10, 101, 11, 103], "제주시 → 동부 → 서귀포 → 남부"),
        ([10, 102, 101, 11], "제주시 → 서부 → 동부 → 서귀포"),
        ([10, 104, 102, 11], "제주시 → 중산간 → 서부 → 서귀포")
    ]

    for locations, loc_desc in four_day_combinations:
        for hashtag_name, hashtags in list(HASHTAG_SETS.items())[:1]:  # 1개만
            scenarios.append({
                "test_id": f"4D_{test_id:03d}",
                "name": f"4일 여행 - {loc_desc} ({hashtag_name})",
                "total_days": 4,
                "daily_locations": locations,
                "hashtags": hashtags,
                "travel_style": "normal",
                "start_date": "2025-04-01"
            })
            test_id += 1

    return scenarios


def create_api_request(scenario):
    """시나리오를 API 요청 형식으로 변환"""
    start_date = datetime.strptime(scenario['start_date'], '%Y-%m-%d')
    end_date = start_date + timedelta(days=scenario['total_days'] - 1)

    return {
        "date": {
            "user_id": f"test_user_{scenario['test_id']}",
            "start_date": start_date.strftime('%Y-%m-%d'),
            "end_date": end_date.strftime('%Y-%m-%d'),
            "arrival_time": "09:00",
            "departure_time": "18:00",
            "start_place": "제주공항",
            "end_place": "제주공항"
        },
        "user": {
            "start_time": "09:00",
            "end_time": "19:00",
            "travel_style": scenario['travel_style'],
            "meal_time_preferences": {
                "lunch": ["12:00", "13:00"],
                "dinner": ["18:00", "19:00"]
            },
            "tags": scenario['hashtags']
        },
        "start_transport_id": 1,
        "end_transport_id": 1,
        "total_days": scenario['total_days'],
        "daily_locations": scenario['daily_locations'],
        "hashtags": scenario['hashtags'],
        "use_mock": True
    }


def analyze_day_result(day_schedule):
    """단일 날짜 결과 분석"""
    analysis = {
        "day": day_schedule.get('day'),
        "date": day_schedule.get('date'),
        "visit_count": len(day_schedule.get('visits', [])),
        "path_segment_count": len(day_schedule.get('path', [])),
        "places": []
    }

    # 방문 장소 정보
    for visit in day_schedule.get('visits', []):
        analysis['places'].append({
            "name": visit.get('place', 'N/A'),
            "category": visit.get('category', 'N/A')
        })

    # 오류 분석
    selection_errors = day_schedule.get('selection_errors', [])
    if selection_errors:
        analysis['has_errors'] = True
        analysis['error_count'] = len(selection_errors)
        analysis['error_types'] = [err.get('place_type') for err in selection_errors]
    else:
        analysis['has_errors'] = False
        analysis['error_count'] = 0

    # 재시도 분석
    retry_history = day_schedule.get('retry_history', [])
    if retry_history:
        analysis['retry_count'] = len(retry_history)
        analysis['first_try_success'] = retry_history[0].get('success', False) if retry_history else True
        analysis['final_strategy'] = retry_history[-1].get('strategy', 'direct') if retry_history else 'direct'
    else:
        analysis['retry_count'] = 0
        analysis['first_try_success'] = True
        analysis['final_strategy'] = 'direct'

    # 선택 요약
    summary = day_schedule.get('selection_summary', {})
    if summary:
        analysis['selection_success_rate'] = summary.get('success_rate', 1.0)
        analysis['types_failed'] = summary.get('types_failed', [])

    return analysis


def run_single_test(scenario):
    """단일 테스트 실행"""
    test_id = scenario['test_id']
    print(f"\n{'='*80}")
    print(f"테스트 ID: {test_id}")
    print(f"시나리오: {scenario['name']}")
    print(f"{'='*80}")

    request_data = create_api_request(scenario)

    result = {
        "test_id": test_id,
        "scenario": scenario,
        "timestamp": datetime.now().isoformat(),
        "success": False,
        "error": None,
        "response": None,
        "analysis": None
    }

    try:
        print(f"📍 지역: {scenario['daily_locations']}")
        print(f"📅 {scenario['total_days']}일 여행")
        print(f"🏷️  태그: {scenario['hashtags']}")

        response = requests.post(
            f"{BASE_URL}/api/users/schedules/init",
            json=request_data,
            timeout=120
        )

        if response.status_code == 200:
            api_result = response.json()
            result['success'] = True
            result['response'] = api_result

            # 결과 분석
            analysis = {
                "overall_success": api_result.get('success', False),
                "total_days": api_result.get('total_days', 0),
                "days": []
            }

            for day_schedule in api_result.get('day_schedules', []):
                day_analysis = analyze_day_result(day_schedule)
                analysis['days'].append(day_analysis)

            # 전체 통계
            total_visits = sum(d['visit_count'] for d in analysis['days'])
            total_errors = sum(d['error_count'] for d in analysis['days'])
            days_with_errors = sum(1 for d in analysis['days'] if d['has_errors'])
            first_try_success_count = sum(1 for d in analysis['days'] if d['first_try_success'])

            analysis['statistics'] = {
                "total_visits": total_visits,
                "avg_visits_per_day": total_visits / len(analysis['days']) if analysis['days'] else 0,
                "total_errors": total_errors,
                "days_with_errors": days_with_errors,
                "first_try_success_rate": first_try_success_count / len(analysis['days']) if analysis['days'] else 0
            }

            result['analysis'] = analysis

            # 간단한 결과 출력
            print(f"\n✅ 성공")
            print(f"   총 방문: {total_visits}곳")
            print(f"   오류 발생 일수: {days_with_errors}/{len(analysis['days'])}")
            print(f"   1차 성공률: {first_try_success_count}/{len(analysis['days'])}")

        else:
            result['error'] = f"HTTP {response.status_code}: {response.text[:200]}"
            print(f"\n❌ 실패: {result['error']}")

    except Exception as e:
        result['error'] = str(e)
        print(f"\n❌ 예외 발생: {e}")

    return result


def save_results(all_results):
    """결과를 JSON 파일로 저장"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 전체 결과 저장
    full_results_path = RESULTS_DIR / f"full_results_{timestamp}.json"
    with open(full_results_path, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"\n📁 전체 결과 저장: {full_results_path}")

    # 요약 결과 생성
    summary = {
        "timestamp": datetime.now().isoformat(),
        "total_tests": len(all_results),
        "successful_tests": sum(1 for r in all_results if r['success']),
        "failed_tests": sum(1 for r in all_results if not r['success']),
        "tests_by_duration": {},
        "tests_by_location": {},
        "error_analysis": {
            "location_code_11_issues": 0,
            "location_code_103_issues": 0,
            "location_code_104_issues": 0,
            "other_errors": []
        },
        "performance_stats": {
            "first_try_success_rate": 0,
            "avg_retries": 0,
            "max_retries": 0
        }
    }

    # 일수별 통계
    for result in all_results:
        if result['success']:
            days = result['scenario']['total_days']
            if days not in summary['tests_by_duration']:
                summary['tests_by_duration'][days] = {
                    "total": 0,
                    "success": 0,
                    "avg_visits": 0
                }

            summary['tests_by_duration'][days]['total'] += 1
            summary['tests_by_duration'][days]['success'] += 1

            if result['analysis']:
                summary['tests_by_duration'][days]['avg_visits'] += result['analysis']['statistics']['total_visits']

    # 평균 계산
    for days, stats in summary['tests_by_duration'].items():
        if stats['success'] > 0:
            stats['avg_visits'] /= stats['success']

    # 오류 분석
    first_try_successes = 0
    total_retries = 0
    max_retries = 0

    for result in all_results:
        if result['success'] and result['analysis']:
            for day in result['analysis']['days']:
                if day['first_try_success']:
                    first_try_successes += 1

                retry_count = day.get('retry_count', 0)
                total_retries += retry_count
                max_retries = max(max_retries, retry_count)

                # 지역별 오류 추적
                if day['has_errors']:
                    for error_type in day.get('error_types', []):
                        # 여기서 지역 코드별 문제 파악 가능
                        pass

    total_days = sum(len(r['analysis']['days']) for r in all_results if r['success'] and r['analysis'])
    if total_days > 0:
        summary['performance_stats']['first_try_success_rate'] = first_try_successes / total_days
        summary['performance_stats']['avg_retries'] = total_retries / total_days
        summary['performance_stats']['max_retries'] = max_retries

    # 요약 저장
    summary_path = RESULTS_DIR / f"summary_{timestamp}.json"
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"📁 요약 결과 저장: {summary_path}")

    # 실패한 테스트만 따로 저장
    failed_tests = [r for r in all_results if not r['success']]
    if failed_tests:
        failed_path = RESULTS_DIR / f"failed_tests_{timestamp}.json"
        with open(failed_path, 'w', encoding='utf-8') as f:
            json.dump(failed_tests, f, ensure_ascii=False, indent=2)
        print(f"📁 실패 테스트 저장: {failed_path}")

    return summary


def print_final_summary(summary):
    """최종 요약 출력"""
    print("\n" + "="*80)
    print("📊 최종 테스트 요약")
    print("="*80)

    print(f"\n총 테스트: {summary['total_tests']}개")
    print(f"✅ 성공: {summary['successful_tests']}개")
    print(f"❌ 실패: {summary['failed_tests']}개")
    print(f"성공률: {summary['successful_tests']/summary['total_tests']*100:.1f}%")

    print(f"\n📈 성능 통계:")
    print(f"  - 1차 시도 성공률: {summary['performance_stats']['first_try_success_rate']*100:.1f}%")
    print(f"  - 평균 재시도 횟수: {summary['performance_stats']['avg_retries']:.2f}회")
    print(f"  - 최대 재시도 횟수: {summary['performance_stats']['max_retries']}회")

    print(f"\n📅 일수별 결과:")
    for days in sorted(summary['tests_by_duration'].keys()):
        stats = summary['tests_by_duration'][days]
        print(f"  {days}일 여행: {stats['success']}/{stats['total']} 성공, "
              f"평균 {stats['avg_visits']:.1f}곳 방문")

    print("="*80)


def check_server():
    """서버 상태 확인"""
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        return response.status_code == 200
    except:
        return False


def main():
    """메인 실행 함수"""
    print("="*80)
    print("🧪 포괄적인 여행 일정 API 테스트")
    print(f"   시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)

    # 서버 확인
    if not check_server():
        print("\n❌ 서버가 실행되지 않았습니다!")
        print("   실행 명령: uvicorn app.main:app --reload")
        return

    print("\n✅ 서버 연결 성공")

    # 시나리오 생성
    scenarios = generate_test_scenarios()
    print(f"\n📋 총 {len(scenarios)}개의 테스트 시나리오 생성")

    # 시나리오별 개수 출력
    scenario_counts = {}
    for s in scenarios:
        days = s['total_days']
        scenario_counts[days] = scenario_counts.get(days, 0) + 1

    for days in sorted(scenario_counts.keys()):
        print(f"   {days}일 여행: {scenario_counts[days]}개")

    # 테스트 실행
    print(f"\n🚀 테스트 시작...\n")
    all_results = []

    for i, scenario in enumerate(scenarios, 1):
        print(f"\n진행률: {i}/{len(scenarios)}")
        result = run_single_test(scenario)
        all_results.append(result)

    # 결과 저장
    print(f"\n\n💾 결과 저장 중...")
    summary = save_results(all_results)

    # 최종 요약 출력
    print_final_summary(summary)

    print(f"\n✅ 모든 테스트 완료!")
    print(f"   종료 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    main()
