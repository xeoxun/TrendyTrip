"""
모든 지역 코드를 활용한 여행 일정 API 테스트
각 테스트 결과를 개별 JSON 파일로 저장
"""

import requests
import json
from datetime import datetime, timedelta
from pathlib import Path

BASE_URL = "http://localhost:8000"
RESULTS_DIR = Path("test_results")
RESULTS_DIR.mkdir(exist_ok=True)

# 제주 지역 코드 정의
LOCATION_CODES = {
    10: "제주시",
    11: "서귀포시",
    101: "동부(구좌/성산)",
    102: "서부(한림/애월)",
    103: "남부(안덕/대정/남원)",
    104: "중산간"
}


def generate_test_scenarios():
    """테스트 시나리오 생성 (간소화)"""
    scenarios = []
    test_id = 1

    # 1일 여행 - 각 지역별 1개씩 (총 6개)
    for loc_code, loc_name in LOCATION_CODES.items():
        scenarios.append({
            "test_id": f"1D_{test_id:03d}",
            "name": f"1일 여행 - {loc_name}",
            "total_days": 1,
            "daily_locations": [loc_code],
            "hashtags": ["자연", "힐링", "바다"],
            "travel_style": "relaxed",
            "start_date": "2025-03-01"
        })
        test_id += 1

    # 2일 여행 - 주요 조합 (총 6개)
    two_day_combinations = [
        ([10, 11], "제주시 → 서귀포"),
        ([10, 101], "제주시 → 동부"),
        ([10, 102], "제주시 → 서부"),
        ([10, 103], "제주시 → 남부"),
        ([101, 102], "동부 → 서부"),
        ([102, 103], "서부 → 남부")
    ]

    for locations, loc_desc in two_day_combinations:
        scenarios.append({
            "test_id": f"2D_{test_id:03d}",
            "name": f"2일 여행 - {loc_desc}",
            "total_days": 2,
            "daily_locations": locations,
            "hashtags": ["맛집", "카페", "풍경"],
            "travel_style": "normal",
            "start_date": "2025-03-10"
        })
        test_id += 1

    # 3일 여행 - 주요 조합 (총 4개)
    three_day_combinations = [
        ([10, 101, 11], "제주시 → 동부 → 서귀포"),
        ([10, 102, 103], "제주시 → 서부 → 남부"),
        ([10, 104, 11], "제주시 → 중산간 → 서귀포"),
        ([101, 102, 103], "동부 → 서부 → 남부")
    ]

    for locations, loc_desc in three_day_combinations:
        scenarios.append({
            "test_id": f"3D_{test_id:03d}",
            "name": f"3일 여행 - {loc_desc}",
            "total_days": 3,
            "daily_locations": locations,
            "hashtags": ["자연", "관광", "사진"],
            "travel_style": "packed",
            "start_date": "2025-03-20"
        })
        test_id += 1

    # 4일 여행 - 대표 조합 (총 2개)
    four_day_combinations = [
        ([10, 101, 11, 103], "제주시 → 동부 → 서귀포 → 남부"),
        ([10, 102, 104, 11], "제주시 → 서부 → 중산간 → 서귀포")
    ]

    for locations, loc_desc in four_day_combinations:
        scenarios.append({
            "test_id": f"4D_{test_id:03d}",
            "name": f"4일 여행 - {loc_desc}",
            "total_days": 4,
            "daily_locations": locations,
            "hashtags": ["힐링", "맛집", "체험"],
            "travel_style": "normal",
            "start_date": "2025-04-01"
        })
        test_id += 1

    return scenarios


def create_api_request(scenario):
    """시나리오를 API 요청 형식으로 변환"""
    start_date = datetime.strptime(scenario['start_date'], '%Y-%m-%d')
    end_date = start_date + timedelta(days=scenario['total_days'] - 1)

    return {
        "date": {
            "user_id": f"test_user_{scenario['test_id']}",
            "start_date": start_date.strftime('%Y-%m-%d'),
            "end_date": end_date.strftime('%Y-%m-%d'),
            "arrival_time": "09:00",
            "departure_time": "18:00",
            "start_place": "제주공항",
            "end_place": "제주공항"
        },
        "user": {
            "start_time": "09:00",
            "end_time": "19:00",
            "travel_style": scenario['travel_style'],
            "meal_time_preferences": {
                "lunch": ["12:00", "13:00"],
                "dinner": ["18:00", "19:00"]
            },
            "tags": scenario['hashtags']
        },
        "start_transport_id": 1,
        "end_transport_id": 1,
        "total_days": scenario['total_days'],
        "daily_locations": scenario['daily_locations'],
        "hashtags": scenario['hashtags'],
        "use_mock": True
    }


def save_test_result(test_id, scenario, request_data, response_data, analysis):
    """개별 테스트 결과를 JSON 파일로 저장"""
    result = {
        "test_id": test_id,
        "test_name": scenario['name'],
        "timestamp": datetime.now().isoformat(),
        "scenario": scenario,
        "request": request_data,
        "response": response_data,
        "analysis": analysis
    }

    # 개별 테스트 결과 저장 (파일명 안전하게 처리)
    safe_name = scenario['name'].replace(' ', '_').replace('→', 'to').replace('/', '_').replace('(', '').replace(')', '').replace('-', '')
    filename = f"{test_id}_{safe_name}.json"
    filepath = RESULTS_DIR / filename

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    return filepath


def analyze_response(api_response):
    """API 응답 분석"""
    if not api_response:
        return {
            "success": False,
            "error": "No response"
        }

    analysis = {
        "overall_success": api_response.get('success', False),
        "total_days": api_response.get('total_days', 0),
        "days": [],
        "statistics": {
            "total_visits": 0,
            "total_errors": 0,
            "days_with_errors": 0,
            "days_with_retries": 0,
            "avg_visits_per_day": 0,
            "first_try_success_rate": 0
        }
    }

    first_try_successes = 0

    for day_schedule in api_response.get('day_schedules', []):
        day_analysis = {
            "day": day_schedule.get('day'),
            "date": day_schedule.get('date'),
            "visit_count": len(day_schedule.get('visits', [])),
            "places": [
                {
                    "name": v.get('place', 'N/A'),
                    "category": v.get('category', 'N/A'),
                    "arrival": v.get('arrival', 'N/A'),
                    "departure": v.get('departure', 'N/A')
                }
                for v in day_schedule.get('visits', [])
            ]
        }

        # 오류 정보
        selection_errors = day_schedule.get('selection_errors', [])
        day_analysis['errors'] = selection_errors
        day_analysis['error_count'] = len(selection_errors)

        # 재시도 정보
        retry_history = day_schedule.get('retry_history', [])
        day_analysis['retry_history'] = retry_history
        day_analysis['retry_count'] = len(retry_history)

        if retry_history:
            day_analysis['first_try_success'] = retry_history[0].get('success', False)
            day_analysis['final_strategy'] = retry_history[-1].get('strategy', 'unknown')
            if day_analysis['first_try_success']:
                first_try_successes += 1
        else:
            day_analysis['first_try_success'] = True
            day_analysis['final_strategy'] = 'direct'
            first_try_successes += 1

        # 선택 요약
        summary = day_schedule.get('selection_summary', {})
        day_analysis['selection_summary'] = {
            "total_selected": summary.get('total_selected', 0),
            "total_requested": summary.get('total_requested', 0),
            "success_rate": summary.get('success_rate', 1.0),
            "types_failed": summary.get('types_failed', [])
        }

        analysis['days'].append(day_analysis)

        # 통계 업데이트
        analysis['statistics']['total_visits'] += day_analysis['visit_count']
        analysis['statistics']['total_errors'] += day_analysis['error_count']
        if day_analysis['error_count'] > 0:
            analysis['statistics']['days_with_errors'] += 1
        if day_analysis['retry_count'] > 0:
            analysis['statistics']['days_with_retries'] += 1

    # 평균 계산
    total_days = len(analysis['days'])
    if total_days > 0:
        analysis['statistics']['avg_visits_per_day'] = analysis['statistics']['total_visits'] / total_days
        analysis['statistics']['first_try_success_rate'] = first_try_successes / total_days

    return analysis


def run_single_test(scenario, scenario_num, total_scenarios):
    """단일 테스트 실행 및 JSON 저장"""
    test_id = scenario['test_id']

    print(f"\n{'='*80}")
    print(f"[{scenario_num}/{total_scenarios}] 테스트 ID: {test_id}")
    print(f"시나리오: {scenario['name']}")
    print(f"{'='*80}")

    request_data = create_api_request(scenario)

    print(f"📍 지역: {scenario['daily_locations']} - {[LOCATION_CODES[loc] for loc in scenario['daily_locations']]}")
    print(f"📅 {scenario['total_days']}일 여행")
    print(f"🏷️  태그: {scenario['hashtags']}")

    try:
        response = requests.post(
            f"{BASE_URL}/api/users/schedules/init",
            json=request_data,
            timeout=120
        )

        if response.status_code == 200:
            api_response = response.json()
            analysis = analyze_response(api_response)

            # JSON 파일로 저장
            filepath = save_test_result(test_id, scenario, request_data, api_response, analysis)

            # 간단한 결과 출력
            stats = analysis['statistics']
            print(f"\n✅ 성공 - 저장: {filepath.name}")
            print(f"   총 방문: {stats['total_visits']}곳")
            print(f"   오류 발생 일수: {stats['days_with_errors']}/{analysis['total_days']}")
            print(f"   재시도 발생 일수: {stats['days_with_retries']}/{analysis['total_days']}")
            print(f"   1차 성공률: {stats['first_try_success_rate']*100:.0f}%")

            return True, analysis

        else:
            error_result = {
                "success": False,
                "error": f"HTTP {response.status_code}: {response.text[:200]}"
            }
            filepath = save_test_result(test_id, scenario, request_data, None, error_result)
            print(f"\n❌ 실패 - 저장: {filepath.name}")
            print(f"   오류: {error_result['error']}")
            return False, error_result

    except Exception as e:
        error_result = {
            "success": False,
            "error": str(e)
        }
        filepath = save_test_result(test_id, scenario, request_data, None, error_result)
        print(f"\n❌ 예외 - 저장: {filepath.name}")
        print(f"   오류: {str(e)}")
        return False, error_result


def create_summary_report(all_results):
    """전체 요약 보고서 생성"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    summary = {
        "timestamp": datetime.now().isoformat(),
        "total_tests": len(all_results),
        "successful_tests": sum(1 for r in all_results if r['success']),
        "failed_tests": sum(1 for r in all_results if not r['success']),
        "tests_by_duration": {},
        "location_analysis": {},
        "performance_stats": {
            "total_visits": 0,
            "total_errors": 0,
            "avg_first_try_success_rate": 0,
            "tests_with_errors": 0
        },
        "detailed_results": []
    }

    # 일수별 통계
    duration_stats = {}
    total_first_try_rate = 0
    success_count = 0

    for result in all_results:
        test_info = {
            "test_id": result['test_id'],
            "name": result['name'],
            "success": result['success'],
            "total_days": result.get('scenario', {}).get('total_days', 0),
            "locations": result.get('scenario', {}).get('daily_locations', [])
        }

        if result['success'] and result.get('analysis'):
            analysis = result['analysis']
            stats = analysis.get('statistics', {})

            test_info['visits'] = stats.get('total_visits', 0)
            test_info['errors'] = stats.get('total_errors', 0)
            test_info['first_try_success_rate'] = stats.get('first_try_success_rate', 0)

            # 통계 누적
            summary['performance_stats']['total_visits'] += stats.get('total_visits', 0)
            summary['performance_stats']['total_errors'] += stats.get('total_errors', 0)
            if stats.get('total_errors', 0) > 0:
                summary['performance_stats']['tests_with_errors'] += 1

            total_first_try_rate += stats.get('first_try_success_rate', 0)
            success_count += 1

            # 일수별 통계
            days = result['scenario']['total_days']
            if days not in duration_stats:
                duration_stats[days] = {
                    "count": 0,
                    "success": 0,
                    "total_visits": 0,
                    "total_errors": 0
                }
            duration_stats[days]['count'] += 1
            duration_stats[days]['success'] += 1
            duration_stats[days]['total_visits'] += stats.get('total_visits', 0)
            duration_stats[days]['total_errors'] += stats.get('total_errors', 0)

        summary['detailed_results'].append(test_info)

    # 평균 계산
    if success_count > 0:
        summary['performance_stats']['avg_first_try_success_rate'] = total_first_try_rate / success_count

    # 일수별 통계 정리
    for days, stats in duration_stats.items():
        if stats['success'] > 0:
            stats['avg_visits'] = stats['total_visits'] / stats['success']
            stats['avg_errors'] = stats['total_errors'] / stats['success']

    summary['tests_by_duration'] = duration_stats

    # 요약 파일 저장
    summary_path = RESULTS_DIR / f"SUMMARY_{timestamp}.json"
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    return summary, summary_path


def print_final_summary(summary, summary_path):
    """최종 요약 출력"""
    print("\n" + "="*80)
    print("📊 최종 테스트 요약")
    print("="*80)

    print(f"\n📁 요약 파일 저장: {summary_path}")

    print(f"\n총 테스트: {summary['total_tests']}개")
    print(f"✅ 성공: {summary['successful_tests']}개")
    print(f"❌ 실패: {summary['failed_tests']}개")

    if summary['total_tests'] > 0:
        success_rate = summary['successful_tests'] / summary['total_tests'] * 100
        print(f"성공률: {success_rate:.1f}%")

    perf = summary['performance_stats']
    print(f"\n📈 성능 통계:")
    print(f"  - 총 방문 장소: {perf['total_visits']}곳")
    print(f"  - 총 오류: {perf['total_errors']}건")
    print(f"  - 오류 발생 테스트: {perf['tests_with_errors']}개")
    print(f"  - 평균 1차 성공률: {perf['avg_first_try_success_rate']*100:.1f}%")

    print(f"\n📅 일수별 결과:")
    for days in sorted(summary['tests_by_duration'].keys()):
        stats = summary['tests_by_duration'][days]
        print(f"  {days}일 여행: {stats['success']}/{stats['count']} 성공")
        if stats['success'] > 0:
            print(f"    - 평균 방문: {stats['avg_visits']:.1f}곳")
            print(f"    - 평균 오류: {stats['avg_errors']:.1f}건")

    print("="*80)


def check_server():
    """서버 상태 확인"""
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        return response.status_code == 200
    except:
        return False


def main():
    """메인 실행 함수"""
    print("="*80)
    print("🧪 전체 지역 코드 여행 일정 API 테스트")
    print(f"   시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)

    # 서버 확인
    if not check_server():
        print("\n❌ 서버가 실행되지 않았습니다!")
        print("   실행 명령: uvicorn app.main:app --reload")
        return

    print("\n✅ 서버 연결 성공")

    # 시나리오 생성
    scenarios = generate_test_scenarios()
    print(f"\n📋 총 {len(scenarios)}개의 테스트 시나리오 생성")

    # 시나리오별 개수 출력
    scenario_counts = {}
    for s in scenarios:
        days = s['total_days']
        scenario_counts[days] = scenario_counts.get(days, 0) + 1

    for days in sorted(scenario_counts.keys()):
        print(f"   {days}일 여행: {scenario_counts[days]}개")

    print(f"\n📁 결과 저장 디렉토리: {RESULTS_DIR.absolute()}")

    # 테스트 실행
    print(f"\n🚀 테스트 시작...\n")
    all_results = []

    for i, scenario in enumerate(scenarios, 1):
        success, analysis = run_single_test(scenario, i, len(scenarios))
        all_results.append({
            "test_id": scenario['test_id'],
            "name": scenario['name'],
            "scenario": scenario,
            "success": success,
            "analysis": analysis
        })

    # 요약 보고서 생성
    print(f"\n\n💾 요약 보고서 생성 중...")
    summary, summary_path = create_summary_report(all_results)

    # 최종 요약 출력
    print_final_summary(summary, summary_path)

    print(f"\n✅ 모든 테스트 완료!")
    print(f"   종료 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\n📁 모든 결과는 '{RESULTS_DIR}' 디렉토리에 저장되었습니다.")


if __name__ == "__main__":
    main()
