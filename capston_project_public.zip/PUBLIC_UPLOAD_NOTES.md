# GitHub 업로드 전 설정

- `be/.env.example`을 `be/.env`로 복사해 새 DB 비밀번호와 네이버 API 인증 정보를 입력하세요.
- `fe/.env.example`을 `fe/.env`로 복사해 새 지도 Client ID를 입력하세요.
- `.env` 파일은 GitHub에 올리지 마세요. 프런트엔드 Client ID는 빌드 후 브라우저에서 확인 가능합니다. 비밀키는 프런트엔드에 넣지 마세요.
- 이전에 공개한 키와 DB 비밀번호는 폐기하거나 교체하세요. 기존 README의 설정 안내도 참고하세요.
- `be/TripScheduler/TripRecommendationSystem/config/database.yaml`은 비밀번호를 공란으로 변경했습니다. 이 선택 설정을 사용한다면 로컬에서 입력하고 Git에 올리지 않도록 관리하세요.
