"""
고급 테스트 케이스 스크립트
- 6-7일 장기 여행
- 다양한 여행 스타일
- 다양한 해시태그 조합
- 극단적 시간 케이스
- 모든 지역 순회
"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests
import json
import time
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8009/api/users/schedules/init"

# 사용 가능한 지역코드
AVAILABLE_LOCATIONS = [10, 20, 101, 102, 103, 104, 105, 201, 202, 203, 204, 205, 206]

def create_test_request(days, daily_locations, hashtags=None, start_time="09:00", end_time="18:00", travel_style="relaxed"):
    """테스트 요청 생성"""
    start_date = "2025-02-01"
    end_date = (datetime.strptime(start_date, "%Y-%m-%d") + timedelta(days=days-1)).strftime("%Y-%m-%d")

    return {
        "date": {
            "user_id": "test_user",
            "start_date": start_date,
            "end_date": end_date,
            "arrival_time": start_time,
            "departure_time": end_time,
            "start_place": "제주국제공항",
            "end_place": "제주국제공항"
        },
        "user": {
            "start_time": start_time,
            "end_time": end_time,
            "travel_style": travel_style,
            "meal_time_preferences": {
                "lunch": ["12:00", "13:00"]
            },
            "tags": hashtags or ["맛집", "카페"]
        },
        "daily_locations": daily_locations,
        "hashtags": hashtags or ["맛집", "카페"],
        "use_mock": False
    }

def run_test(test_name, days, daily_locations, hashtags=None, start_time="09:00", end_time="18:00", travel_style="relaxed"):
    """단일 테스트 실행"""
    print(f"\n{'='*60}")
    print(f"테스트: {test_name}")
    print(f"일수: {days}일, 지역코드: {daily_locations}")
    print(f"시간: {start_time} ~ {end_time}, 스타일: {travel_style}")
    print(f"해시태그: {hashtags or ['맛집', '카페']}")
    print(f"{'='*60}")

    request_data = create_test_request(days, daily_locations, hashtags, start_time, end_time, travel_style)

    try:
        start_time_ts = time.time()
        response = requests.post(BASE_URL, json=request_data, timeout=600)
        elapsed_time = time.time() - start_time_ts

        result = response.json()

        if result.get("success"):
            print(f"SUCCESS (소요시간: {elapsed_time:.2f}초)")

            total_places = 0
            for day_schedule in result.get("day_schedules", []):
                day = day_schedule.get("day")
                visits = day_schedule.get("visits", [])
                visit_names = [v.get("place", "?") for v in visits]
                total_places += len(visits)

                print(f"  Day {day}: {len(visits)}개 장소")
                if len(visit_names) > 4:
                    print(f"    {' -> '.join(visit_names[:2])} -> ... -> {visit_names[-1]}")
                else:
                    print(f"    {' -> '.join(visit_names)}")

                errors = day_schedule.get("selection_errors", [])
                if errors:
                    print(f"    [!] 선택 에러: {len(errors)}개")

            print(f"  >> 총 {total_places}개 장소 방문")
            return {"success": True, "elapsed": elapsed_time, "total_places": total_places, "name": test_name}
        else:
            print(f"FAILED: {result.get('error', 'Unknown error')}")
            return {"success": False, "error": result.get("error"), "name": test_name}

    except requests.exceptions.Timeout:
        print(f"TIMEOUT (600초 초과)")
        return {"success": False, "error": "timeout", "name": test_name}
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return {"success": False, "error": str(e), "name": test_name}

def main():
    results = []

    print("\n" + "="*70)
    print("Advanced Tests - 고급 테스트 케이스 시작")
    print("="*70)

    # ========== 6-7일 장기 여행 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 6-7일 장기 여행 테스트")
    print("#"*70)

    # 6일 전체 일주
    results.append(run_test("6일-제주완전일주", 6, [10, 101, 103, 20, 201, 202]))

    # 7일 여행
    results.append(run_test("7일-제주일주", 7, [10, 101, 102, 103, 20, 201, 202]))

    # ========== 다양한 해시태그 조합 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 다양한 해시태그 조합 테스트")
    print("#"*70)

    # 액티비티 중심
    results.append(run_test("2일-액티비티", 2, [10, 20], ["액티비티", "체험", "레저"]))

    # 힐링/휴식 중심
    results.append(run_test("2일-힐링", 2, [101, 102], ["힐링", "휴식", "자연"]))

    # 문화/역사 중심
    results.append(run_test("2일-문화역사", 2, [10, 201], ["문화", "역사", "박물관"]))

    # 가족 여행
    results.append(run_test("2일-가족여행", 2, [10, 20], ["가족", "아이", "체험"]))

    # 커플 여행
    results.append(run_test("2일-커플여행", 2, [101, 102], ["데이트", "로맨틱", "뷰맛집"]))

    # 사진 명소
    results.append(run_test("2일-사진명소", 2, [201, 202], ["인스타", "사진", "포토스팟"]))

    # ========== 여행 스타일 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 여행 스타일 테스트")
    print("#"*70)

    # relaxed 스타일
    results.append(run_test("2일-relaxed스타일", 2, [10, 20], travel_style="relaxed"))

    # normal 스타일
    results.append(run_test("2일-normal스타일", 2, [10, 20], travel_style="normal"))

    # tight 스타일
    results.append(run_test("2일-tight스타일", 2, [10, 20], travel_style="tight"))

    # ========== 극단적 시간 케이스 ==========
    print("\n\n" + "#"*70)
    print("# 극단적 시간 케이스")
    print("#"*70)

    # 아침만 (06:00 ~ 12:00)
    results.append(run_test("1일-이른아침", 1, [10], start_time="06:00", end_time="12:00"))

    # 저녁만 (17:00 ~ 23:00)
    results.append(run_test("1일-늦은저녁", 1, [20], start_time="17:00", end_time="23:00"))

    # 매우 긴 하루 (06:00 ~ 23:00)
    results.append(run_test("1일-풀타임", 1, [10], start_time="06:00", end_time="23:00"))

    # ========== 지역 조합 특수 케이스 ==========
    print("\n\n" + "#"*70)
    print("# 지역 조합 특수 케이스")
    print("#"*70)

    # 멀리 떨어진 지역 연속 (제주시 -> 서귀포시 -> 성산)
    results.append(run_test("3일-원거리이동", 3, [10, 20, 201]))

    # 인접 지역 집중 (애월 -> 한림 -> 한경)
    results.append(run_test("3일-인접지역", 3, [101, 103, 104]))

    # 교차 이동 (제주시 -> 성산 -> 서귀포시 -> 애월)
    results.append(run_test("4일-교차이동", 4, [10, 201, 20, 101]))

    # 같은 큰 지역 내 세부 지역 (서귀포권)
    results.append(run_test("3일-서귀포권집중", 3, [20, 102, 203]))

    # ========== 모든 지역 순회 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 모든 지역 순회 테스트")
    print("#"*70)

    # 13개 지역 전체 순회 (13일)
    all_locations = [10, 101, 103, 104, 105, 20, 102, 201, 202, 203, 204, 205, 206]
    results.append(run_test("13일-전지역순회", 13, all_locations))

    # ========== 반복 패턴 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 반복 패턴 테스트")
    print("#"*70)

    # 2지역 왕복 (제주시 -> 서귀포시 -> 제주시 -> 서귀포시)
    results.append(run_test("4일-2지역왕복", 4, [10, 20, 10, 20]))

    # 3지역 순환 (제주시 -> 서귀포시 -> 애월 -> 제주시 -> 서귀포시 -> 애월)
    results.append(run_test("6일-3지역순환", 6, [10, 20, 101, 10, 20, 101]))

    # ========== 결과 요약 ==========
    print("\n\n" + "="*70)
    print("테스트 결과 요약")
    print("="*70)

    success_count = sum(1 for r in results if r.get("success"))
    total_count = len(results)

    print(f"\n전체: {total_count}개 테스트")
    print(f"성공: {success_count}개")
    print(f"실패: {total_count - success_count}개")
    print(f"성공률: {success_count/total_count*100:.1f}%")

    # 실패 테스트 목록
    failed = [r for r in results if not r.get("success")]
    if failed:
        print("\n실패한 테스트:")
        for f in failed:
            print(f"  - {f.get('name', 'Unknown')}: {f.get('error', 'Unknown')}")

    # 소요시간 통계
    successful = [r for r in results if r.get("success")]
    if successful:
        times = [r["elapsed"] for r in successful]
        places = [r.get("total_places", 0) for r in successful]
        print(f"\n소요시간 통계:")
        print(f"  최소: {min(times):.2f}초")
        print(f"  최대: {max(times):.2f}초")
        print(f"  평균: {sum(times)/len(times):.2f}초")
        print(f"\n장소 수 통계:")
        print(f"  최소: {min(places)}개")
        print(f"  최대: {max(places)}개")
        print(f"  평균: {sum(places)/len(places):.1f}개")

    # 카테고리별 결과
    print("\n카테고리별 결과:")
    categories = {
        "장기여행(6-7일)": [r for r in results if "6일" in r.get("name", "") or "7일" in r.get("name", "")],
        "해시태그": [r for r in results if any(x in r.get("name", "") for x in ["액티비티", "힐링", "문화", "가족", "커플", "사진"])],
        "여행스타일": [r for r in results if "스타일" in r.get("name", "")],
        "시간변형": [r for r in results if any(x in r.get("name", "") for x in ["아침", "저녁", "풀타임"])],
        "지역조합": [r for r in results if any(x in r.get("name", "") for x in ["원거리", "인접", "교차", "서귀포권"])],
        "순회/반복": [r for r in results if any(x in r.get("name", "") for x in ["전지역", "왕복", "순환"])],
    }

    for cat_name, cat_results in categories.items():
        if cat_results:
            success = sum(1 for r in cat_results if r.get("success"))
            print(f"  {cat_name}: {success}/{len(cat_results)} 성공")

if __name__ == "__main__":
    main()
