# -*- coding: utf-8 -*-
"""2일 여행 실제 API 모드 테스트"""
import requests
import json

BASE_URL = "http://localhost:8000"

test_data = {
    "date": {
        "user_id": "test_2day_real",
        "start_date": "2025-02-15",
        "end_date": "2025-02-16",
        "arrival_time": "10:00",
        "departure_time": "17:00",
        "start_place": "제주공항",
        "end_place": "제주공항"
    },
    "user": {
        "start_time": "09:00",
        "end_time": "19:00",
        "travel_style": "normal",
        "meal_time_preferences": {
            "lunch": ["12:00", "14:00"],
            "dinner": ["18:00", "20:00"]
        },
        "tags": ["맛집", "카페", "풍경"]
    },
    "start_transport_id": 1,
    "end_transport_id": 1,
    "total_days": 2,
    "daily_locations": [10, 11],  # 제주시, 서귀포
    "hashtags": ["맛집", "카페", "풍경"],
    "use_mock": False  # 실제 API!
}

print("=" * 80)
print("2-Day Trip REAL API Mode Test")
print("=" * 80)
print(f"\nuse_mock = {test_data['use_mock']}")

try:
    response = requests.post(
        f"{BASE_URL}/api/users/schedules/init",
        json=test_data,
        timeout=120
    )

    print(f"Response: {response.status_code}")

    if response.status_code == 200:
        result = response.json()

        for day_idx, day in enumerate(result.get('day_schedules', []), 1):
            visits = day.get('visits', [])
            path = day.get('path', [])
            retry_history = day.get('retry_history', [])

            print(f"\n--- Day {day_idx} ---")
            print(f"Visits: {len(visits)}")
            print(f"Path segments: {len(path)}")
            print(f"Retry attempts: {len(retry_history)}")

            if retry_history:
                last = retry_history[-1]
                print(f"Final attempt: {last.get('attempt')} - {'SUCCESS' if last.get('success') else 'FAILED'}")

            if path:
                print(f"Path example: {path[0][:2]}")

        # 저장
        with open('test_2day_real_api_result.json', 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

        total_path = sum(len(d.get('path', [])) for d in result.get('day_schedules', []))
        print(f"\n{'='*80}")
        print(f"Total path segments: {total_path}")
        print(f"Result saved to test_2day_real_api_result.json")
        print(f"{'='*80}")

    else:
        print(f"Error: {response.text[:500]}")

except Exception as e:
    print(f"Failed: {e}")
    import traceback
    traceback.print_exc()
