"""
다양한 지역코드 조합 테스트 스크립트
"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests
import json
import time
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8009/api/users/schedules/init"

# 사용 가능한 지역코드
AVAILABLE_LOCATIONS = [10, 20, 101, 102, 103, 104, 105, 201, 202, 203, 204, 205, 206]

def create_test_request(days, daily_locations, hashtags=None):
    """테스트 요청 생성"""
    start_date = "2025-02-01"
    end_date = (datetime.strptime(start_date, "%Y-%m-%d") + timedelta(days=days-1)).strftime("%Y-%m-%d")

    return {
        "date": {
            "user_id": "test_user",
            "start_date": start_date,
            "end_date": end_date,
            "arrival_time": "09:00",
            "departure_time": "18:00",
            "start_place": "제주국제공항",
            "end_place": "제주국제공항"
        },
        "user": {
            "start_time": "09:00",
            "end_time": "18:00",
            "travel_style": "relaxed",
            "meal_time_preferences": {
                "lunch": ["12:00", "13:00"]
            },
            "tags": hashtags or ["맛집", "카페"]
        },
        "daily_locations": daily_locations,
        "hashtags": hashtags or ["맛집", "카페"],
        "use_mock": False
    }

def run_test(test_name, days, daily_locations, hashtags=None):
    """단일 테스트 실행"""
    print(f"\n{'='*60}")
    print(f"테스트: {test_name}")
    print(f"일수: {days}일, 지역코드: {daily_locations}")
    print(f"해시태그: {hashtags or ['맛집', '카페']}")
    print(f"{'='*60}")

    request_data = create_test_request(days, daily_locations, hashtags)

    try:
        start_time = time.time()
        response = requests.post(BASE_URL, json=request_data, timeout=300)
        elapsed_time = time.time() - start_time

        result = response.json()

        if result.get("success"):
            print(f"✅ SUCCESS (소요시간: {elapsed_time:.2f}초)")

            # 각 날짜별 방문지 요약
            for day_schedule in result.get("day_schedules", []):
                day = day_schedule.get("day")
                visits = day_schedule.get("visits", [])
                visit_names = [v.get("place", "?") for v in visits]
                retry = day_schedule.get("retry_history", [{}])[-1]

                print(f"  Day {day}: {len(visits)}개 장소")
                print(f"    방문지: {' → '.join(visit_names[:3])}{'...' if len(visit_names) > 3 else ''}")

                # 에러 확인
                errors = day_schedule.get("selection_errors", [])
                if errors:
                    print(f"    ⚠️ 선택 에러: {len(errors)}개")

            return {"success": True, "elapsed": elapsed_time, "result": result}
        else:
            print(f"❌ FAILED: {result.get('error', 'Unknown error')}")
            return {"success": False, "error": result.get("error")}

    except requests.exceptions.Timeout:
        print(f"❌ TIMEOUT (300초 초과)")
        return {"success": False, "error": "timeout"}
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        return {"success": False, "error": str(e)}

def main():
    results = []

    print("\n" + "="*70)
    print("🚀 다양한 지역코드 조합 테스트 시작")
    print("="*70)

    # ========== 1일차 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 1일차 테스트")
    print("#"*70)

    # 1-1: 제주시 (10)
    results.append(run_test("1일-제주시", 1, [10]))

    # 1-2: 서귀포시 (20)
    results.append(run_test("1일-서귀포시", 1, [20]))

    # 1-3: 애월 (101)
    results.append(run_test("1일-애월", 1, [101]))

    # 1-4: 성산 (201)
    results.append(run_test("1일-성산", 1, [201]))

    # ========== 2일차 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 2일차 테스트")
    print("#"*70)

    # 2-1: 제주시 → 서귀포시
    results.append(run_test("2일-제주시→서귀포시", 2, [10, 20]))

    # 2-2: 애월 → 중문 (102)
    results.append(run_test("2일-애월→중문", 2, [101, 102]))

    # 2-3: 성산 → 표선 (202)
    results.append(run_test("2일-성산→표선", 2, [201, 202]))

    # 2-4: 같은 지역 연속 (제주시 → 제주시)
    results.append(run_test("2일-같은지역연속", 2, [10, 10]))

    # ========== 3일차 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 3일차 테스트")
    print("#"*70)

    # 3-1: 제주시 → 서귀포시 → 애월
    results.append(run_test("3일-제주시→서귀포시→애월", 3, [10, 20, 101]))

    # 3-2: 애월 → 한림(103) → 한경(104)
    results.append(run_test("3일-서쪽해안", 3, [101, 103, 104]))

    # 3-3: 성산 → 표선 → 남원(203)
    results.append(run_test("3일-동쪽해안", 3, [201, 202, 203]))

    # 3-4: 일주 코스 (제주시 → 성산 → 서귀포시)
    results.append(run_test("3일-일주코스", 3, [10, 201, 20]))

    # ========== 다양한 해시태그 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 해시태그 조합 테스트")
    print("#"*70)

    # 해시태그: 자연경관
    results.append(run_test("1일-자연경관", 1, [10], ["자연경관", "힐링"]))

    # 해시태그: 맛집투어
    results.append(run_test("1일-맛집투어", 1, [20], ["맛집", "현지맛집"]))

    # ========== 결과 요약 ==========
    print("\n\n" + "="*70)
    print("📊 테스트 결과 요약")
    print("="*70)

    success_count = sum(1 for r in results if r.get("success"))
    total_count = len(results)

    print(f"\n전체: {total_count}개 테스트")
    print(f"성공: {success_count}개")
    print(f"실패: {total_count - success_count}개")
    print(f"성공률: {success_count/total_count*100:.1f}%")

    # 실패 테스트 목록
    failed = [r for r in results if not r.get("success")]
    if failed:
        print("\n❌ 실패한 테스트:")
        for f in failed:
            print(f"  - {f.get('error', 'Unknown')}")

if __name__ == "__main__":
    main()
