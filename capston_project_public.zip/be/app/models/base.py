# app/models/base.py
from sqlalchemy.orm import declarative_base

Base = declarative_base()
