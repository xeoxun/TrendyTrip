import os

def print_directory_tree(root_path=".", exclude_dirs=None, indent=""):
    if exclude_dirs is None:
        exclude_dirs = []

    try:
        items = sorted(os.listdir(root_path))
    except PermissionError:
        print(f"{indent}[권한 없음] {root_path}")
        return

    for idx, item in enumerate(items):
        path = os.path.join(root_path, item)
        is_last = idx == len(items) - 1
        branch = "└── " if is_last else "├── "
        print(f"{indent}{branch}{item}")

        if os.path.isdir(path) and item not in exclude_dirs:
            extension = "    " if is_last else "│   "
            print_directory_tree(path, exclude_dirs, indent + extension)


if __name__ == "__main__":
    # 현재 디렉토리(".") 기준
    project_root = "."

    # 제외할 폴더 지정
    exclude = ["__pycache__", ".git", "venv", 'tests', '.venv', '%programdata%']

    print(project_root)
    print_directory_tree(project_root, exclude_dirs=exclude)
