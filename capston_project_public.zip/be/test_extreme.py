"""극한 상황 테스트 - 실제 API 호출 확인"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests
import json
import time

BASE_URL = "http://localhost:8009/api/users/schedules/init"

def test_extreme_case(name, start_time, end_time, locations, days=1):
    """극한 케이스 테스트"""
    from datetime import datetime, timedelta

    start_date = datetime.now() + timedelta(days=7)
    end_date = start_date + timedelta(days=days-1)

    request_data = {
        "date": {
            "user_id": "extreme_test",
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "arrival_time": start_time,
            "departure_time": end_time,
            "start_place": "제주국제공항",
            "end_place": "제주국제공항"
        },
        "user": {
            "start_time": start_time,
            "end_time": end_time,
            "travel_style": "relaxed",
            "meal_time_preferences": {
                "breakfast": ["08:00", "09:00"],
                "lunch": ["12:00", "13:00"],
                "dinner": ["18:00", "19:00"]
            },
            "tags": ["맛집", "카페"]
        },
        "daily_locations": locations,
        "use_mock": False  # 실제 API 사용
    }

    print(f"\n{'='*60}")
    print(f"테스트: {name}")
    print(f"시간: {start_time} ~ {end_time}")
    print(f"지역: {locations}")
    print(f"use_mock: False (실제 Naver API 사용)")
    print(f"{'='*60}")

    start = time.time()
    try:
        response = requests.post(BASE_URL, json=request_data, timeout=300)
        elapsed = time.time() - start

        if response.status_code == 200:
            data = response.json()
            if data.get("success") and data.get("day_schedules"):
                print(f"\n✅ SUCCESS ({elapsed:.1f}초)")

                for day_schedule in data["day_schedules"]:
                    day = day_schedule.get("day", "?")
                    date = day_schedule.get("date", "?")
                    visits = day_schedule.get("visits", [])
                    path = day_schedule.get("path", [])

                    print(f"\n[Day {day}] {date} - {len(visits)}개 장소 방문")

                    for v in visits:
                        order = v.get("order", "?")
                        place = v.get("place", "?")
                        arrival = v.get("arrival_str", "?")
                        departure = v.get("departure_str", "?")
                        category = v.get("category", "?")
                        print(f"  {order}. {place} ({arrival}~{departure}) [{category}]")

                    if path:
                        print(f"  → 경로 데이터: {len(path)}개 구간 (Naver API 응답)")

                return True
            else:
                print(f"\n❌ FAIL - {data.get('error', '일정 생성 실패')}")
                return False
        else:
            print(f"\n❌ FAIL - HTTP {response.status_code}")
            print(response.text[:200])
            return False

    except Exception as e:
        elapsed = time.time() - start
        print(f"\n❌ FAIL - {str(e)} ({elapsed:.1f}초)")
        return False

def main():
    print("="*60)
    print("극한 상황 테스트 - 실제 Naver API 호출")
    print("="*60)

    results = []

    # 1. 3시간 최단 일정
    results.append(("3시간 최단", test_extreme_case(
        "3시간 최단 일정 (10:00~13:00)",
        "10:00", "13:00", [10]
    )))

    # 2. 이른 아침 (06:00~12:00)
    results.append(("이른아침", test_extreme_case(
        "이른 아침 일정 (06:00~12:00)",
        "06:00", "12:00", [10]
    )))

    # 3. 늦은 저녁 (17:00~23:00)
    results.append(("늦은저녁", test_extreme_case(
        "늦은 저녁 일정 (17:00~23:00)",
        "17:00", "23:00", [20]
    )))

    # 4. 풀타임 (06:00~23:00)
    results.append(("풀타임", test_extreme_case(
        "풀타임 일정 (06:00~23:00)",
        "06:00", "23:00", [10]
    )))

    print("\n" + "="*60)
    print("극한 테스트 결과 요약")
    print("="*60)

    success_count = sum(1 for _, r in results if r)
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {name}: {status}")

    print(f"\n총 {len(results)}개 중 {success_count}개 성공")
    print("\n※ 모든 테스트는 use_mock=False로 실제 Naver API를 호출했습니다.")

if __name__ == "__main__":
    main()
