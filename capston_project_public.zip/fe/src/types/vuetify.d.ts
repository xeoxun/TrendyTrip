declare module 'vuetify/styles'
