"""
엣지 케이스 테스트 스크립트
- 4-5일 여행
- 데이터가 적은 지역
- 극단적 시간 설정
"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests
import json
import time
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8009/api/users/schedules/init"

# 사용 가능한 지역코드
AVAILABLE_LOCATIONS = [10, 20, 101, 102, 103, 104, 105, 201, 202, 203, 204, 205, 206]

def create_test_request(days, daily_locations, hashtags=None, start_time="09:00", end_time="18:00"):
    """테스트 요청 생성"""
    start_date = "2025-02-01"
    end_date = (datetime.strptime(start_date, "%Y-%m-%d") + timedelta(days=days-1)).strftime("%Y-%m-%d")

    return {
        "date": {
            "user_id": "test_user",
            "start_date": start_date,
            "end_date": end_date,
            "arrival_time": start_time,
            "departure_time": end_time,
            "start_place": "제주국제공항",
            "end_place": "제주국제공항"
        },
        "user": {
            "start_time": start_time,
            "end_time": end_time,
            "travel_style": "relaxed",
            "meal_time_preferences": {
                "lunch": ["12:00", "13:00"]
            },
            "tags": hashtags or ["맛집", "카페"]
        },
        "daily_locations": daily_locations,
        "hashtags": hashtags or ["맛집", "카페"],
        "use_mock": False
    }

def run_test(test_name, days, daily_locations, hashtags=None, start_time="09:00", end_time="18:00"):
    """단일 테스트 실행"""
    print(f"\n{'='*60}")
    print(f"테스트: {test_name}")
    print(f"일수: {days}일, 지역코드: {daily_locations}")
    print(f"시간: {start_time} ~ {end_time}")
    print(f"해시태그: {hashtags or ['맛집', '카페']}")
    print(f"{'='*60}")

    request_data = create_test_request(days, daily_locations, hashtags, start_time, end_time)

    try:
        start_time_ts = time.time()
        response = requests.post(BASE_URL, json=request_data, timeout=600)  # 10분 타임아웃
        elapsed_time = time.time() - start_time_ts

        result = response.json()

        if result.get("success"):
            print(f"SUCCESS (소요시간: {elapsed_time:.2f}초)")

            # 각 날짜별 방문지 요약
            for day_schedule in result.get("day_schedules", []):
                day = day_schedule.get("day")
                visits = day_schedule.get("visits", [])
                visit_names = [v.get("place", "?") for v in visits]

                print(f"  Day {day}: {len(visits)}개 장소")
                print(f"    방문지: {' -> '.join(visit_names[:3])}{'...' if len(visit_names) > 3 else ''}")

                # 에러 확인
                errors = day_schedule.get("selection_errors", [])
                if errors:
                    print(f"    [!] 선택 에러: {len(errors)}개")

            return {"success": True, "elapsed": elapsed_time, "result": result}
        else:
            print(f"FAILED: {result.get('error', 'Unknown error')}")
            return {"success": False, "error": result.get("error")}

    except requests.exceptions.Timeout:
        print(f"TIMEOUT (600초 초과)")
        return {"success": False, "error": "timeout"}
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return {"success": False, "error": str(e)}

def main():
    results = []

    print("\n" + "="*70)
    print("Edge Case Tests - 엣지 케이스 테스트 시작")
    print("="*70)

    # ========== 4일 여행 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 4일 여행 테스트")
    print("#"*70)

    # 4-1: 제주 일주 코스
    results.append(run_test("4일-제주일주", 4, [10, 201, 20, 101]))

    # 4-2: 동쪽 집중
    results.append(run_test("4일-동쪽집중", 4, [201, 202, 203, 204]))

    # ========== 5일 여행 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 5일 여행 테스트")
    print("#"*70)

    # 5-1: 전체 일주
    results.append(run_test("5일-전체일주", 5, [10, 101, 103, 20, 201]))

    # 5-2: 같은 지역 반복
    results.append(run_test("5일-제주시반복", 5, [10, 10, 10, 10, 10]))

    # ========== 데이터가 적은 지역 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 데이터가 적은 지역 테스트")
    print("#"*70)

    # 남원 (203)
    results.append(run_test("1일-남원", 1, [203]))

    # 안덕 (204)
    results.append(run_test("1일-안덕", 1, [204]))

    # 대정 (205)
    results.append(run_test("1일-대정", 1, [205]))

    # 한경 (104)
    results.append(run_test("1일-한경", 1, [104]))

    # 구좌 (105)
    results.append(run_test("1일-구좌", 1, [105]))

    # 조천 (206)
    results.append(run_test("1일-조천", 1, [206]))

    # ========== 작은 지역 연속 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 작은 지역 연속 테스트")
    print("#"*70)

    # 서쪽 작은 지역들
    results.append(run_test("3일-서쪽소지역", 3, [103, 104, 105]))

    # 동쪽 작은 지역들
    results.append(run_test("3일-동쪽소지역", 3, [203, 204, 206]))

    # ========== 시간 변형 테스트 ==========
    print("\n\n" + "#"*70)
    print("# 시간 변형 테스트")
    print("#"*70)

    # 짧은 하루 (10:00 ~ 15:00)
    results.append(run_test("1일-짧은하루", 1, [10], start_time="10:00", end_time="15:00"))

    # 긴 하루 (08:00 ~ 21:00)
    results.append(run_test("1일-긴하루", 1, [10], start_time="08:00", end_time="21:00"))

    # 오후만 (14:00 ~ 20:00)
    results.append(run_test("1일-오후만", 1, [20], start_time="14:00", end_time="20:00"))

    # ========== 결과 요약 ==========
    print("\n\n" + "="*70)
    print("테스트 결과 요약")
    print("="*70)

    success_count = sum(1 for r in results if r.get("success"))
    total_count = len(results)

    print(f"\n전체: {total_count}개 테스트")
    print(f"성공: {success_count}개")
    print(f"실패: {total_count - success_count}개")
    print(f"성공률: {success_count/total_count*100:.1f}%")

    # 실패 테스트 목록
    failed = [r for r in results if not r.get("success")]
    if failed:
        print("\n실패한 테스트:")
        for f in failed:
            print(f"  - {f.get('error', 'Unknown')}")

    # 소요시간 통계
    successful = [r for r in results if r.get("success")]
    if successful:
        times = [r["elapsed"] for r in successful]
        print(f"\n소요시간 통계:")
        print(f"  최소: {min(times):.2f}초")
        print(f"  최대: {max(times):.2f}초")
        print(f"  평균: {sum(times)/len(times):.2f}초")

if __name__ == "__main__":
    main()
