# -*- coding: utf-8 -*-
"""1일 여행 OR-Tools 실패 원인 디버깅 테스트"""
import requests
import json

BASE_URL = "http://localhost:8000"

test_data = {
    "date": {
        "user_id": "debug_user_001",
        "start_date": "2025-02-01",
        "end_date": "2025-02-01",
        "arrival_time": "09:00",
        "departure_time": "18:00",
        "start_place": "제주공항",
        "end_place": "제주공항"
    },
    "user": {
        "start_time": "09:00",
        "end_time": "18:00",
        "travel_style": "relaxed",
        "meal_time_preferences": {
            "lunch": ["12:00", "13:00"],
            "dinner": ["18:00", "19:00"]
        },
        "tags": ["자연", "힐링", "바다"]
    },
    "start_transport_id": 1,
    "end_transport_id": 1,
    "total_days": 1,
    "daily_locations": [10],
    "hashtags": ["자연", "힐링", "바다"],
    "use_mock": True
}

print("=" * 80)
print("1-Day Trip OR-Tools Debugging")
print("=" * 80)
print("\nRequest info:")
print(f"  use_mock: {test_data['use_mock']}")
print(f"  location: {test_data['daily_locations']}")
print(f"  hashtags: {test_data['hashtags']}")

try:
    print("\nCalling API...")
    response = requests.post(
        f"{BASE_URL}/api/users/schedules/init",
        json=test_data,
        timeout=120
    )

    print(f"Response status: {response.status_code}")

    if response.status_code == 200:
        result = response.json()
        day_schedules = result.get('day_schedules', [])

        if day_schedules:
            day1 = day_schedules[0]
            print(f"\nDay 1 results:")
            print(f"  Visits: {len(day1.get('visits', []))}")
            print(f"  Path segments: {len(day1.get('path', []))}")

            retry_history = day1.get('retry_history', [])
            print(f"\nRetry history: {len(retry_history)} attempts")

            for r in retry_history:
                attempt = r.get('attempt', '?')
                success = "SUCCESS" if r.get('success') else "FAILED"
                strategy = r.get('strategy', '')

                if strategy:
                    print(f"  Attempt {attempt}: {success} [strategy: {strategy}]")
                else:
                    time_limit = r.get('time_limit', '?')
                    window_slack = r.get('window_slack', '?')
                    print(f"  Attempt {attempt}: {success} [limit: {time_limit}s, slack: {window_slack}min]")

                if not r.get('success') and r.get('error'):
                    error_msg = r.get('error', '')[:200]
                    print(f"      Error: {error_msg}")

            print("\n" + "=" * 80)
            if day1.get('path'):
                print("SUCCESS: path data generated!")
            else:
                print("FAILED: no path data - likely used fallback")
            print("=" * 80)

            with open('debug_1day_result.json', 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print("\nResult saved to debug_1day_result.json")
        else:
            print("\nERROR: day_schedules is empty")
    else:
        print(f"\nAPI Error:")
        print(f"  Status: {response.status_code}")
        print(f"  Response: {response.text[:500]}")

except Exception as e:
    print(f"\nTest failed: {e}")
    import traceback
    traceback.print_exc()

print("\nNext: Check server logs for use_mock flag value in prepare_matrices")
